 reglas generales 
domina tu oc 
promp ingeniero